use shop;
drop table if exists t_user;
create table t_user(
	id int(10)primary key auto_increment,
	username varchar(20),
	password varchar(20),
	nickname varchar(20),
	status int(2),
	type int(2)
);
drop table if exists t_good;
create table t_good(
	id int(10)primary key auto_increment,
	goodname varchar(20),
	goodprise varchar(20),
	photo varchar(20)
	
);
drop table if exists t_car;
create table t_car(
	id int (10) primary key auto_increment,
	goodname varchar(20) ,
	goodprise varchar(20) ,
	userid int (10),
	goodnumber int (10),
	constraint foreign key (userid) references t_user(id)
);

insert into t_good (goodname,goodprise,photo) value('��Ȫˮ','2','img/��Ȫˮ.jpg');
insert into t_good (goodname,goodprise,photo) value('���','15','img/���.jpg');
insert into t_good (goodname,goodprise,photo) value('����','10','img/����.jpg');
insert into t_good (goodname,goodprise,photo) value('ˮ��','18','img/ˮ��.jpg');


insert into t_user (username,password,nickname,status,type) value('admin','111','admin',1,1);
insert into t_user (username,password,nickname,status,type) value('user','111','user',1,0);
insert into t_food(goodname,goodprise,userid,goodnumber)value('��Ϊ','5999',1,1);
