package com.cn.msg.model;

public class shopException extends RuntimeException {


	private static final long serialVersionUID = -1253187390004893352L;

	public shopException() {
		super();
	}

	public shopException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public shopException(String message, Throwable cause) {
		super(message, cause);
	}

	public shopException(String message) {
		super(message);
	}

	public shopException(Throwable cause) {
		super(cause);
	}
	
}
