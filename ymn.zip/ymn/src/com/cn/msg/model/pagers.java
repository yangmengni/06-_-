package com.cn.msg.model;

import java.util.List;

public class pagers<E> {
	//ҳ���С
	private int pagesize;
	//ҳ���һ����¼����
	private int pagIndex;
	//�ܼ�¼����
	private int totalRecord;
	//�ܹ�����ҳ
	private int tatolPage;
	//ÿ����¼������
	private List<E> data;
	public int getPagesize() {
		return pagesize;
	}
	public void setPagesize(int pagesize) {
		this.pagesize = pagesize;
	}
	public int getPagIndex() {
		return pagIndex;
	}
	public void setPagIndex(int pagIndex) {
		this.pagIndex = pagIndex;
	}
	public int getTotalRecord() {
		return totalRecord;
	}
	public void setTotalRecord(int totalRecord) {
		this.totalRecord = totalRecord;
	}
	public int getTatolPage() {
		return tatolPage;
	}
	public void setTatolPage(int tatolPage) {
		this.tatolPage = tatolPage;
	}
	public List<E> getData() {
		return data;
	}
	public void setData(List<E> data) {
		this.data = data;
	}
}
