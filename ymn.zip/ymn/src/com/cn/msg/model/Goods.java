package com.cn.msg.model;

public class Goods {
	private int id;
	private String goodName;
	private String goodPrise;
	private String photo;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getGoodName() {
		return goodName;
	}
	public void setGoodName(String goodName) {
		this.goodName = goodName;
	}
	public String getGoodPrise() {
		return goodPrise;
	}
	public void setGoodPrise(String goodPrise) {
		this.goodPrise = goodPrise;
	}
	public String getPhoto() {
		return photo;
	}
	public void setPhoto(String photo) {
		this.photo = photo;
	}
}
