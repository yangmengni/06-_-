package com.cn.msg.dao;

public class DAOFactory {
	public static IUserdao getIUserdao(){
		return new Userdao();
	}
	public static IGoodsdao getIGoodsdao(){
		return new Goodsdao();
	}
	public static ICardao getICardao(){
		return new Cardao();
	}
}
