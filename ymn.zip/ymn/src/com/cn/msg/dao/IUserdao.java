package com.cn.msg.dao;


import com.cn.msg.model.User;
import com.cn.msg.model.pagers;

public interface IUserdao {
	public void add(User user);
	public void delete(int id);
	public void update(User user);
	public User load(int id);
	public pagers<User> list(String condition,int pageIndex,int pagesize);
	public User login(String username,String password);
}
