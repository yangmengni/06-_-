package com.cn.msg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cn.msg.model.Goods;
import com.cn.msg.util.DBUtil;

public class Goodsdao implements IGoodsdao {

	public List<Goods> load() {
		
			Connection con = null;
			PreparedStatement ps = null;
			ResultSet rs = null;
			Goods goods = null;
			List<Goods> list = new ArrayList<Goods>();
			try {
				con = DBUtil.getConnection();
				String sql = "select * from t_good";
				ps = con.prepareStatement(sql);
				rs = ps.executeQuery();
				while(rs.next()){
					goods = new Goods();
					goods.setId(rs.getInt("id"));
					goods.setGoodName(rs.getString("goodname"));
					goods.setGoodPrise(rs.getString("goodprise"));
					goods.setPhoto(rs.getString("photo"));
					list.add(goods);
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}finally{
				DBUtil.close(rs);
				DBUtil.close(ps);
				DBUtil.close(con);
			}

			return list;
		
	}

}
