package com.cn.msg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cn.msg.model.Car;
import com.cn.msg.model.Goods;
import com.cn.msg.util.DBUtil;

public class Cardao implements ICardao {

	public List<Car> load() {
		
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		Car c = null;
		List<Car> list = new ArrayList<Car>();
		try {
			con = DBUtil.getConnection();
			String sql = "select * from t_car";
			ps = con.prepareStatement(sql);
			rs = ps.executeQuery();
			while(rs.next()){
				c = new Car();
				c.setId(rs.getInt("id"));
				c.setGoodName(rs.getString("goodname"));
				c.setGoodPrice(rs.getString("goodprise"));
				c.setGoodNumber(rs.getString("goodnumber"));
				c.setUserId(rs.getInt("userid"));
				list.add(c);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			DBUtil.close(rs);
			DBUtil.close(ps);
			DBUtil.close(con);
		}

		return list;
	}
	public static void main(String[] args) {
		Cardao c=new Cardao();
		Goods g = c.load("2");
		c.add(g, 1, 2);
	}
	@SuppressWarnings("resource")
	public void add(Goods g, int i,int id) {
		int goodid = g.getId();
		int num = 0;
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			con = DBUtil.getConnection();
			String sql = "select goodnumber from t_car where goodname=?";
			ps = con.prepareStatement(sql);
			ps.setString(1,g.getGoodName());
			rs = ps.executeQuery();
			while(rs.next()){
				num = rs.getInt("goodnumber");
				num++;
			}
			if(num>0){
				
				String sqlupdate = "update t_car set goodname ='"+g.getGoodName()+"', goodprise ='"+g.getGoodPrise()+"', userid="+id+",goodnumber="+num+" where id ="+goodid;
				ps = con.prepareStatement(sqlupdate);
			}else{
				String sqlinsert = "insert into t_car(goodname,goodprise,goodnumber,userid) values('"+g.getGoodName()+"','"+g.getGoodPrise()+"',"+1+","+id+")";
				ps = con.prepareStatement(sqlinsert);
			}
			
			ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			DBUtil.close(rs);
			DBUtil.close(ps);
			DBUtil.close(con);
		}

	}

	public void delete(int id) {
		Connection con = null;
		PreparedStatement ps = null;
		try {
			con = DBUtil.getConnection();
			String sql = "delete from t_car where id = ?";
			ps = con.prepareStatement(sql);
			ps.setInt(1, id);
			ps.executeUpdate();
	
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			DBUtil.close(ps);
			DBUtil.close(con);
		}

	}

	public Goods load(String id) {
		Integer i = new Integer(id);
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		Goods g= null;
		try {
			con = DBUtil.getConnection();
			String sql = "select * from t_good where id="+i;
			ps = con.prepareStatement(sql);
			rs = ps.executeQuery();
			while(rs.next()){
				g = new Goods();
				g.setGoodName(rs.getString("goodname"));
				g.setGoodPrise(rs.getString("goodprise"));
				g.setId(rs.getInt("id"));
				g.setPhoto(rs.getString("photo"));
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			DBUtil.close(rs);
			DBUtil.close(ps);
			DBUtil.close(con);
		}
		return g;
	}

}
