package com.cn.msg.dao;

import java.util.List;

import com.cn.msg.model.Car;
import com.cn.msg.model.Goods;

public interface ICardao {
	public List<Car> load();
	public void add(Goods g,int i,int id);
	public void delete(int id);
	public Goods load(String id);
}
