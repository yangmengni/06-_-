package com.cn.msg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cn.msg.model.User;
import com.cn.msg.model.pagers;
import com.cn.msg.model.shopException;
import com.cn.msg.util.DBUtil;

public class Userdao implements IUserdao {
//	public static void main(String[] args) {
//		new Userdao().add(new User());
//	}
	@SuppressWarnings("resource")
	public void add(User user) {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			con = DBUtil.getConnection();
			String sql = "select count(*) from t_user where username=?";
			ps = con.prepareStatement(sql);
			ps.setString(1,user.getUsername());
			rs = ps.executeQuery();
			while(rs.next()){
			//	System.out.println("���ԣ��û�����");
				if(rs.getInt(1)>0)throw new shopException("���ӵ��û��Ѿ�����");
			}
			sql = "insert into t_user values(null,?,?,?,?,?)";
			ps = con.prepareStatement(sql);
			ps.setString(1, user.getUsername());
			ps.setString(2, user.getPassword());
			ps.setString(3, user.getNickname());
			ps.setInt(4, user.getStatus());
			ps.setInt(5, user.getType());
			ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			DBUtil.close(rs);
			DBUtil.close(ps);
			DBUtil.close(con);
		}

	}

	public void delete(int id) {
		Connection con = null;
		PreparedStatement ps = null;
		try {
			con = DBUtil.getConnection();
			String sql = "delete from t_user where id = ?";
			ps = con.prepareStatement(sql);
			ps.setInt(1, id);
			ps.executeUpdate();
	
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			DBUtil.close(ps);
			DBUtil.close(con);
		}

	}

	public void update(User user) {
		Connection con = null;
		PreparedStatement ps = null;
		try {
			con = DBUtil.getConnection();
			String sql = "update t_user set password = ?,nickname = ? status = ? type = ? where id = ?";
			ps = con.prepareStatement(sql);
			ps.setString(1,user.getPassword());
			ps.setString(2, user.getNickname());
			ps.setInt(3, user.getStatus());
			ps.setInt(4, user.getType());
			ps.setInt(5, user.getId());
			ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			DBUtil.close(ps);
			DBUtil.close(con);
		}

	}

	public User load(int id) {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		User u = null;
		try {
			con = DBUtil.getConnection();
			String sql = "select * from t_user where id=?";
			ps = con.prepareStatement(sql);
			ps.setInt(1, id);
			rs = ps.executeQuery();
			while(rs.next()){
				u = new User();
				u.setId(rs.getInt("id"));
				u.setUsername(rs.getString("username"));
				u.setPassword(rs.getString("password"));
				u.setNickname(rs.getString("nickname"));
				u.setStatus(rs.getInt("status"));
				u.setType(rs.getInt("type"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			DBUtil.close(rs);
			DBUtil.close(ps);
			DBUtil.close(con);
		}

		return u;
	}

	
//ʵ�ַ�ҳ
	@SuppressWarnings("resource")
	public pagers<User> list(String condition,int pageIndex,int pagesize) {
		//System.out.println(condition+pageIndex+pagesize);
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		User u = null;
		pagers<User> pager = new pagers<User>();
		List<User> users = new ArrayList<User>();
		try {
			if(pageIndex<=0)pageIndex=1;
			int start = (pageIndex-1)*pagesize;
			con = DBUtil.getConnection();
			String sql = "select * from t_user";
			String sqlcount = "select count(*) from t_user";
			if(condition!=null||!("".equals(condition))){
				sql+=" where username like '%"+condition+"%' or nickname like '%"+condition+"%'";
				sqlcount+=" where username like '%"+condition+"%' or nickname like '%"+condition+"%'";
			}
			sql+="limit "+start+","+pagesize;
			//System.out.println(sql);
			//System.out.println(sqlcount);
			ps = con.prepareStatement(sql);
			rs = ps.executeQuery();
			while(rs.next()){
				u = new User();
				u.setId(rs.getInt("id"));
				u.setUsername(rs.getString("username"));
				u.setPassword(rs.getString("password"));
				u.setNickname(rs.getString("nickname"));
				u.setStatus(rs.getInt("status"));
				u.setType(rs.getInt("type"));
				users.add(u);
			}
			ps = con.prepareStatement(sqlcount);
			rs = ps.executeQuery();
			int tatolRecord = 0;
			while(rs.next()){
				tatolRecord = (rs.getInt(1));
				
			}
			int tatolpage = (tatolRecord-1)/pagesize+1;
			//System.out.println(tatolpage);
			pager.setTotalRecord(tatolRecord);
			pager.setTatolPage(tatolpage);
			pager.setPagIndex(pageIndex);
			pager.setPagesize(pagesize);
			
		} catch (SQLException e) {
			
		}finally{
			DBUtil.close(rs);
			DBUtil.close(ps);
			DBUtil.close(con);
		}
		pager.setData(users);
		return pager;
	}
//��¼�ж�
	public User login(String username, String password) {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		User u = null;
		try {
			con = DBUtil.getConnection();
			//System.out.println("���ݿ����ӳɹ�");
			String sql = "select * from t_user where username = ?";
			ps = con.prepareStatement(sql);
			
			ps.setString(1, username);
			rs = ps.executeQuery();
			while(rs.next()){
				u = new User();
				u.setId(rs.getInt("id"));
				u.setUsername(rs.getString("username"));
				u.setPassword(rs.getString("password"));
				u.setNickname(rs.getString("nickname"));
				u.setStatus(rs.getInt("status"));
				u.setType(rs.getInt("type"));
			}
			if(u==null)throw new shopException("�û������ڣ�");
			if(!u.getPassword().equals(password))throw new shopException("�û����벻��ȷ��  ");
			
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			DBUtil.close(rs);
			DBUtil.close(ps);
			DBUtil.close(con);
		}

		return u;
	}
}
