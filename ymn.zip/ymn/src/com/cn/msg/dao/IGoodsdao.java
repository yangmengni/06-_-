package com.cn.msg.dao;

import java.util.List;

import com.cn.msg.model.Goods;


public interface IGoodsdao {
	public List<Goods> load();
}
