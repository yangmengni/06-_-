package com.cn.msg.util;

import java.io.IOException;
import java.util.Properties;


public class textproperties {
	public static void main(String[] args) {
		Properties properties = new Properties();
		try {
			properties.load(textproperties.class.getClassLoader().getResourceAsStream("jdbc.properties"));
			String username = properties.getProperty("username");
			System.out.println(username);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
