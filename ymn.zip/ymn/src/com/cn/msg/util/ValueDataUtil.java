package com.cn.msg.util;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

public class ValueDataUtil {
	
	public static boolean ValueData(HttpServletRequest request,String[] fields) {
		boolean flag = true;
		Map<String, String> error = new HashMap<String, String>();
		for(String field:fields){
			String value = request.getParameter(field);
			if(value==null||"".equals(value.trim())){
				String Name = null;
				flag = false;
				if(field.equals("username")){
					Name = "�û���";
				}
				if(field.equals("password")){
					Name = "�û�����";
				}
				if(field.equals("nickname")){
					Name = "�û��ǳ�";
				}
				error.put(field, Name+"����Ϊ��");
			}
		}
		if(!flag)request.setAttribute("error", error);
		return flag;
	}
	public static String showError(HttpServletRequest request,String field){
		@SuppressWarnings("unchecked")
		Map<String, String> error = (Map<String, String>) request.getAttribute("error");
		String Msg = " ";
		if(error==null)return Msg;
		Msg = error.get(field);
		if(Msg==null)return Msg = " ";
		return Msg;
	}
}
